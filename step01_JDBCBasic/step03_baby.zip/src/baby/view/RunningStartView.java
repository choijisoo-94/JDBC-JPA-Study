package baby.view;

import java.util.ArrayList;

import baby.controller.OrdersController;


public class RunningStartView {
	
	public static void main(String [] args){
		OrdersController controller = OrdersController.getInstance();
		
		System.out.println("-- 검색 --");
		OrdersController.getSittersDuration("단기");
		
		
		
	}
	
}